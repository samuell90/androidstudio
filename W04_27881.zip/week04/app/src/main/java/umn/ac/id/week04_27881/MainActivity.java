package umn.ac.id.week04_27881;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText etIsian, eturl;
    private Button btnKirim, btnBrowse;
    private TextView tvJawaban;
    private Button btnHal1, btnHal2;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etIsian = findViewById(R.id.isian);
        eturl = findViewById(R.id.url);
        btnBrowse = findViewById(R.id.buttonBrowse);
        btnKirim = findViewById(R.id.buttonKirim);
        tvJawaban = findViewById(R.id.jawaban);
        btnHal1 = findViewById(R.id.main_button_change_1);
        btnHal2 = findViewById(R.id.main_button_change_2);

        btnBrowse.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View v){
               String urlText = eturl.getText().toString();
               if(urlText.isEmpty())
               {
                   urlText = "http://www.umn.ac.id";
               }
               Intent browseIntent = new Intent (Intent.ACTION_VIEW);
               browseIntent.setData(Uri.parse(urlText));
               if(browseIntent.resolveActivity(getPackageManager()) != null)
               {
                   startActivity(browseIntent);
               }

           }
        });

        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intentDua = new Intent (MainActivity.this, MainActivity2.class);
                String isian = etIsian.getText().toString();
                intentDua.putExtra("PesanDariMain", isian);
                startActivityForResult(intentDua, 1);
            }

        });

        btnHal1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent (MainActivity.this, secondActivity.class);
                startActivity(intent);
            }

        });

        btnHal2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent (MainActivity.this, ThirdActivity.class);
                startActivity(intent);
            }

        });


//    @Override
//    public void onActivityResult (int requestCode, int resultCode, Intent data) {
//
//        if (requestCode == 1)
//            {
//                if (resultCode == RESULT_OK)
//                {
//                    String jawaban = data.getStringExtra("Jawaban");
//                    tvJawaban.setText(jawaban);
//                }
//            }
//            super.onActivityResult(requestCode, resultCode, data);
//
//        }



    }
}