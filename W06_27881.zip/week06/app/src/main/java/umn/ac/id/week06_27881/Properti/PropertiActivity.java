package umn.ac.id.week06_27881.Properti;

import androidx.appcompat.app.AppCompatActivity;
import umn.ac.id.week06_27881.R;

import android.os.Bundle;

public class PropertiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_properti);
    }
}